# 阿里云设置
S3 AccessKeyId: `AccessKeyId`

S3 SecretAccessKey: `SecretAccessKey`

S3 BucketName: `bucket-name`

S3 EndpointUrl: `https://<bucket-name>.<region>.aliyuncs.com`

S3 Signature Version: `s3v4`

S3 Region Name：`region` 

# Minio设置

S3 AccessKeyId: `AccessKeyId`

S3 SecretAccessKey: `SecretAccessKey`

S3 BucketName: `bucket-name`

S3 EndpointUrl: api接口地址

S3 Signature Version: `s3v4`

S3 Region Name：根据`configurations`里面设置的 `Server Location` 